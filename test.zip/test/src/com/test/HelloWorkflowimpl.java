package com.test;

public class HelloWorkflowimpl implements HelloWorkflow {
    @Override
    public String getGreeting(String name) {
        return "Hello" + name +"!";
    }
}

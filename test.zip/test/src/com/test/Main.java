package com.test;

import com.uber.cadence.worker.Worker;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Worker.Factory f = new Worker.Factory(  "simple-domain");
        Worker w = f.newWorker("hello");
        w.registerWorkflowImplementationTypes(HelloWorkflowimpl.class);
        f.start();
    }
}
